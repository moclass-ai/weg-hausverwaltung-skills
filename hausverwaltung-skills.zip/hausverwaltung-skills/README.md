# Hausverwaltung-Skills für Claude (WEG, deutsches Recht)

Drei Skills, die zusammen die Aufgaben einer Hausverwaltung nach dem Wohnungseigentumsgesetz abdecken. Gedacht für Wohnungseigentümergemeinschaften in Selbstverwaltung, Verwaltungsbeiräte und kleine Verwaltungen.

**Rechtsstand: November 2026.** Die Skills ersetzen keine Rechtsberatung, siehe [Haftungsausschluss](#haftungsausschluss).

## Aufbau

Jede Aufgabe ist ein Posten mit festem Code. Der Code steht in jeder Ausgabe, damit alles einer Aufgabe zugeordnet bleibt.

| Skill | Posten | Inhalt |
|---|---|---|
| [`hausverwaltung-kaufmaennisch`](skills/hausverwaltung-kaufmaennisch/SKILL.md) | K1–K20 | Wirtschaftsplan, Hausgeld, Mahnwesen, Rechnungsprüfung, Buchhaltung, Rücklage, Jahresabrechnung, Vermögensbericht, Nebenkostenabrechnung, Geldbestand-Nachweis |
| [`hausverwaltung-technisch`](skills/hausverwaltung-technisch/SKILL.md) | T1–T20 | Begehung, Wartungsplan, Prüfpflichten, Schäden, Notfälle, Angebote, Erhaltungsplanung, Gewährleistung, Sicherheitseinrichtungen, Versicherungsschäden |
| [`hausverwaltung-organisation-recht`](skills/hausverwaltung-organisation-recht/SKILL.md) | O1–O25 | Versammlung, Beschlüsse, Niederschrift, Beschluss-Sammlung, Verträge, Versicherungen, Hausordnung, Schriftverkehr, Beirat, Verwalterwechsel, Jahreskalender, Gesamtübersicht |

Die drei Skills verweisen aufeinander (z. B. T8 Erhaltungsplanung an K8 Rücklage, T9 Angebotsvergleich an O6 Beschlussvorlage). Am besten alle drei zusammen installieren.

## Abdeckung eines üblichen Leistungskatalogs

| Leistung | Posten |
|---|---|
| Wirtschaftsplan je Wirtschaftsjahr | K3 |
| Jahresabrechnung und Berichtswesen | K10, K12, K17 |
| Eigentümerversammlung, Tagesordnung, Beschlussentwürfe, Niederschrift | O5, O6, O7, O8, O9 |
| Hausordnung erstellen und durchführen | O23, O15 |
| Verträge für die Gemeinschaft | O12, O2 |
| Überwachung von Dienstkräften | T11, O20 |
| Geldverwaltung, Rücklagenkonten, Geldbestand-Nachweise | K2, K8, K20 |
| Rechnungskontrolle und -anweisung | K6 |
| Buchführung | K7 |
| Technische Kontrollen am Gemeinschaftseigentum | T2, T3, T4 |
| Beratung, Auftragsvergabe, Überwachung, Abrechnungskontrolle | T7, T9, K6 |
| Sofortmaßnahmen in Schadensfällen | T6 |
| Schlüsselverwaltung | T15 |
| Check der Sicherheitseinrichtungen | T19 |
| Allgemeine Verwaltung, Schriftverkehr mit Behörden und Firmen | O24 |
| Kopien wichtiger Vorgänge an Beirat und Eigentümer | O25 |
| Instandhaltungsplanung, Kostenschätzung | T8, T9 |
| Mahnwesen | K5 |
| Versicherungsschäden im Sondereigentum | T20 |
| Aufwendige Instandsetzungen, Sanierungen | T9, T17 |
| Nebenkostenabrechnung für vermietete Einheiten | K19 |

## Installation

Jeder Ordner unter `skills/` ist ein eigenständiger Skill mit einer `SKILL.md`.

- **Claude Code:** die drei Ordner nach `~/.claude/skills/` kopieren.
- **Claude (App):** jeden Ordner als eigenen Skill hinzufügen.

## Benutzung

Einfach die Aufgabe beschreiben, Claude wählt den passenden Skill. Beispiele:

- „Zeige alle Posten“ – Gesamtübersicht über K, T und O mit Zuständigem, Frist und Status
- „Erstelle den Wirtschaftsplan 2027“ (K3)
- „Prüfe diese Rechnung“ (K6)
- „Rechne die Nebenkosten für die vermietete Wohnung ab“ (K19)
- „Wasserschaden im Keller, was jetzt?“ (T6, T13)
- „Bereite die Eigentümerversammlung vor“ (O5, O6)
- „Entwirf eine Hausordnung“ (O23)

Die Skills fragen nur ab, was für den jeweiligen Posten fehlt, schätzen keine Zahlen und beenden jede Abrechnung mit einer Rechenprobe.

## Haftungsausschluss

Die Skills sind eine Arbeitshilfe und keine Rechtsberatung, Steuerberatung oder technische Fachplanung. Die genannten Paragraphen sind Orientierung zum oben genannten Rechtsstand; Gesetze, Fristen und Rechtsprechung ändern sich. Wer die Skills einsetzt, prüft Ergebnisse selbst und zieht bei Streit, Klage, Haftungs- oder Steuerfragen einen Fachanwalt für Miet- und Wohnungseigentumsrecht, einen Steuerberater oder einen Sachverständigen hinzu. Nutzung auf eigene Verantwortung.

## Mitmachen

Korrekturen und Ergänzungen sind willkommen, besonders bei Rechtsänderungen. Bitte bei jeder Änderung an Fristen oder Paragraphen die Fundstelle angeben und den Rechtsstand in der betroffenen `SKILL.md` anpassen. Neue Posten bekommen den nächsten freien Code; bestehende Codes bleiben stabil.

## Lizenz

MIT, siehe [LICENSE](LICENSE).
