---
name: "hausverwaltung-kaufmaennisch"
description: "Kaufmännische Hausverwaltung einer WEG: Wirtschaftsplan, Hausgeld, Mahnwesen, Rechnungsprüfung, Buchhaltung, Rücklage, Jahresabrechnung, Nebenkostenabrechnung. Auch bei \"zeige alle Posten Finanzen\"."
---

# Hausverwaltung – Kaufmännische Verwaltung (Posten K1–K20)

Dieser Skill deckt alle Geld- und Abrechnungsaufgaben einer Hausverwaltung ab. Schwerpunkt: Wohnungseigentümergemeinschaft (WEG) in Deutschland, auch in Selbstverwaltung. Geschwister-Skills: `hausverwaltung-technisch` (T-Posten) und `hausverwaltung-organisation-recht` (O-Posten, dort auch die Gesamtübersicht aller Posten).

**Rechtsstand: November 2026** (WEG in der Fassung der Änderung vom 10.10.2024; Heizkostenverordnung, Betriebskostenverordnung und CO2-Kostenaufteilungsgesetz in der dann geltenden Fassung). Rechtsträgerin ist die **Gemeinschaft der Wohnungseigentümer (GdWE)**: Ihr gehören Konten und Rücklage, sie ist Gläubigerin des Hausgelds und Vertragspartnerin (§ 9a WEG).

## Grundregeln

1. **Nie Zahlen schätzen.** Fehlt ein Beleg, Kontostand oder Schlüssel, benenne die Lücke und frage gezielt nach. Rechne mit dem, was vorliegt, und kennzeichne Annahmen sichtbar.
2. **Verteilerschlüssel kommen aus der Gemeinschaftsordnung oder aus Beschlüssen**, nicht aus Gewohnheit. Gesetzlicher Auffangschlüssel sind die Miteigentumsanteile (§ 16 Abs. 2 WEG). Im Zweifel nach der Fundstelle fragen.
3. **Geld folgt Beschluss.** Vorschüsse, Nachschüsse, Sonderumlagen und Entnahmen aus der Rücklage brauchen einen Beschluss. Prüfe bei jeder Zahlung: Gibt es Beschluss, Auftrag oder Vertrag dazu?
4. **Rechtsstand prüfen.** Die genannten Paragraphen sind Orientierung. Wenn eine Frist, ein Betrag oder eine Pflicht die Antwort trägt, prüfe den aktuellen Stand per Websuche. Du gibst keine Rechtsberatung; bei Streit, Klage oder Haftungsfragen auf Fachanwalt oder Eigentümerverband verweisen.
5. **Jede Ausgabe nennt den Postencode** (z. B. „K10 Jahresabrechnung“), damit alles einer Aufgabe zugeordnet bleibt.
6. **Rechenprobe ist Pflicht.** Jede Abrechnung endet mit einer Kontrollrechnung (siehe K10).
7. **Mit Werkzeug rechnen.** Steht eine Code- oder Tabellenumgebung zur Verfügung, dort rechnen und nicht im Kopf. Kaufmännisch auf Cent runden, Rundungsdifferenzen offen ausweisen.

## Eckdaten, die du zuerst brauchst

Frage nur ab, was für den konkreten Posten fehlt: Anzahl Einheiten und Miteigentumsanteile, Verteilerschlüssel je Kostenart, Abrechnungsjahr, Konten und Bestände, aktueller Wirtschaftsplan, Rücklagenstand, genutzte Verwaltungssoftware (z. B. Dotega) und deren Exporte, bestehende Verträge mit Kosten.

## Postenkatalog

| Code | Posten | Was zu tun ist | Turnus |
|---|---|---|---|
| K1 | Stammdaten & Verteilerschlüssel | Einheiten, Eigentümer, MEA, Wohnflächen, Schlüssel je Kostenart mit Fundstelle erfassen und aktuell halten | bei Änderung |
| K2 | Bankkonten | Bewirtschaftungs- und Rücklagenkonto auf den Namen der Gemeinschaft, Verfügungsberechtigte, Vier-Augen-Prinzip, keine Vermischung mit Privatgeld | einmalig, bei Wechsel |
| K3 | Wirtschaftsplan | Kosten je Kostenart planen, Rücklagenzuführung, Verteilung, Vorschüsse je Einheit; beschlossen werden die Vorschüsse, nicht das Zahlenwerk (§ 28 Abs. 1 WEG); Prüfung und Stellungnahme des Beirats (§ 29 Abs. 2 WEG) | jährlich, je Kalenderjahr |
| K4 | Hausgeld-Sollstellung & Einzug | Monatliche Sollstellung, SEPA-Mandate oder Daueraufträge, Fälligkeit laut Beschluss | monatlich |
| K5 | Zahlungsüberwachung & Mahnwesen | Offene-Posten-Liste, Zahlungserinnerung, Mahnstufen, Verzugszinsen (§ 288 BGB), Verjährung im Blick (regelmäßig drei Jahre, §§ 195, 199 BGB), Vorbereitung Hausgeldklage der GdWE | monatlich |
| K6 | Rechnungsprüfung & Zahlungsverkehr | Sachlich und rechnerisch prüfen, Auftrag/Beschluss zuordnen, Kostenart und Schlüssel festlegen, Freigabe, Skonto, fristgerechte Zahlung; E-Rechnungen empfangen und im Originalformat ablegen | laufend |
| K7 | Laufende Buchhaltung | Einnahmen/Ausgaben nach Kostenarten buchen, Bankabstimmung, Belegablage mit fortlaufender Nummer | monatlich |
| K8 | Erhaltungsrücklage | Zuführung laut Plan, getrennte sichere Anlage, Entnahme nur per Beschluss, Soll-Ist-Stand | laufend, Bericht jährlich |
| K9 | Sonderumlagen | Bedarf berechnen, Verteilung, Fälligkeit, Beschlusstext, Einzug und Verwendungsnachweis | bei Bedarf |
| K10 | Jahresabrechnung | Gesamtabrechnung, Einzelabrechnungen, Kontenentwicklung, Rücklagendarstellung; beschlossen wird nur die Abrechnungsspitze, also Nachschüsse bzw. Anpassung der Vorschüsse (§ 28 Abs. 2 WEG) | jährlich, üblich im 1. Halbjahr |
| K11 | Heiz- und Warmwasserkosten | Verbrauchsabhängige Abrechnung nach Heizkostenverordnung, Daten für Messdienst, Plausibilität, CO2-Kostenausweis für vermietende Eigentümer; fernablesbare Messtechnik und Verbrauchsinformationen (mit T12) | jährlich |
| K12 | Vermögensbericht | Stand der Rücklagen und Aufstellung des wesentlichen Gemeinschaftsvermögens inkl. Forderungen und Verbindlichkeiten (§ 28 Abs. 4 WEG); jedem Eigentümer zur Verfügung stellen, ein Beschluss ist nicht vorgesehen | jährlich |
| K13 | Belegprüfung | Unterlagen für Beirat oder Kassenprüfer aufbereiten, Prüfbericht, offene Punkte klären | jährlich vor der Versammlung |
| K14 | Bescheinigung § 35a EStG | Haushaltsnahe Dienst- und Handwerkerleistungen je Einheit ausweisen (nur Arbeitskosten, unbar bezahlt) | jährlich mit der Abrechnung |
| K15 | Steuern, Abgaben, Personal | Grundbesitzabgaben falls über die WEG, Hausmeister als Minijob (Minijob-Zentrale, Unfallversicherung), Sonderfälle wie PV-Erträge an Steuerberater | laufend |
| K16 | Kosten-Controlling Verträge | Versorger, Versicherungsprämien, Wartungskosten vergleichen, Kündigungsfristen im Blick, Einsparvorschläge | jährlich |
| K17 | Soll-Ist & Liquidität | Budgetvergleich je Kostenart, Liquiditätsvorschau, Warnung bei Unterdeckung | quartalsweise |
| K18 | Eigentümerwechsel kaufmännisch | Hausgeldschuldner ab Umschreibung im Grundbuch, Abgrenzung, Abrechnungsspitze, SEPA-Mandat neu | bei Verkauf |
| K19 | Mietverwaltung Finanzen & Nebenkostenabrechnung (nur vermietete Einheiten) | Mieteingang, Kaution getrennt anlegen, Nebenkostenabrechnung (Betriebskostenabrechnung) an Mieter binnen 12 Monaten nach Abrechnungszeitraum (§ 556 Abs. 3 BGB), Mieterhöhung rechnen | monatlich / jährlich |
| K20 | Geldbestand-Nachweis | Kontostände aller Konten zum Stichtag mit Auszug oder Saldenbestätigung belegen, Buchbestand mit Bankbestand abstimmen, Differenzen erklären; für Beirat, Versammlung und Verwalterwechsel | jährlich, auf Verlangen |

## Arbeitsweisen für die Kernposten

### K3 Wirtschaftsplan
1. Vorjahres-Ist je Kostenart holen, bekannte Änderungen einpreisen (Preisanpassungen, neue Verträge, geplante Maßnahmen).
2. Rücklagenzuführung aus der Erhaltungsplanung ableiten (Abgleich mit T8), nicht pauschal fortschreiben.
3. Je Kostenart den Schlüssel anwenden, Vorschuss je Einheit und Monat ausweisen.
4. Ausgabe: Gesamtplan, Einzelpläne je Einheit, Veränderung zum Vorjahr in Euro und Prozent, Beschlussvorschlag.

### K5 Mahnwesen
Stufen: freundliche Zahlungserinnerung, 1. Mahnung mit Frist, 2. Mahnung mit Ankündigung rechtlicher Schritte, Übergabe an O18. Jedes Schreiben nennt Einheit, Zeitraum, Betrag, Fälligkeit, Bankverbindung der Gemeinschaft. Ton sachlich, ohne Vorwurf. Vor der Klage: Beschlusslage und Vertretung der Gemeinschaft prüfen lassen. Klägerin ist die GdWE; zuständig ist ausschließlich das Amtsgericht am Ort der Anlage (§ 43 Abs. 2 WEG). Verzug setzt Fälligkeit laut Beschluss voraus; ist ein Kalendertermin beschlossen, tritt Verzug ohne Mahnung ein (§ 286 Abs. 2 BGB).

### K6 Rechnungsprüfung
Prüfliste: Rechnungsempfänger ist die Gemeinschaft, Leistung erbracht und abgenommen, Menge und Preis entsprechen dem Angebot, Auftrag/Beschluss vorhanden, Kostenart und Schlüssel, umlagefähig ja/nein, Anteil Arbeitskosten für § 35a, Zahlungsziel/Skonto. Seit 1.1.2025 muss die GdWE E-Rechnungen (strukturiertes Format wie XRechnung oder ZUGFeRD) empfangen können; eine PDF per E-Mail ist keine E-Rechnung. E-Rechnungen im Originalformat aufbewahren. Ergebnis: „freigeben“, „klären“ oder „zurückweisen“ mit Begründung.

### K10 Jahresabrechnung
1. Alle Kontobewegungen des Jahres nach Kostenarten ordnen (reine Einnahmen-Ausgaben-Rechnung).
2. Gesamtabrechnung, dann Einzelabrechnung je Einheit mit Schlüssel, geleisteten Vorschüssen und Ergebnis (Nachschuss oder Guthaben).
3. Rücklage: Anfangsbestand, Soll-Zuführung, tatsächliche Zuführung, Entnahmen, Endbestand.
4. **Rechenprobe:** Anfangsbestand aller Konten + Einnahmen − Ausgaben = Endbestand aller Konten. Summe der Einzelabrechnungen = Gesamtabrechnung. Abweichungen benennen, nicht glätten.
5. Abrechnungsspitze je Einheit: Abrechnungsergebnis minus beschlossene Soll-Vorschüsse. Tatsächliche Zahlungen und Rückstände getrennt daneben zeigen; Rückstände bleiben aus dem Vorschussbeschluss geschuldet und gehören nicht in die Spitze.
6. Ausgabe zusätzlich: K12 Vermögensbericht, K14 Bescheinigungen, K20 Geldbestand-Nachweis, Beschlussvorschlag über Nachschüsse und Anpassung der Vorschüsse.

### K11 Heizkosten – Stand der Pflichten
- Nicht fernablesbare Heizkostenverteiler, Wärmemengen- und Warmwasserzähler müssen bis 31.12.2026 nachgerüstet oder getauscht sein (§ 5 Abs. 3 HeizkostenV). Ausnahme bei technischer Unmöglichkeit oder unangemessenem Aufwand; Kaltwasserzähler sind nicht erfasst. Fehlt die Umrüstung, können Mieter ihren Heizkostenanteil um 3 % kürzen.
- Sind fernablesbare Geräte eingebaut, sind monatliche Verbrauchsinformationen bereitzustellen.
- CO2-Kosten: Der Vermieteranteil richtet sich nach dem Stufenmodell des CO2-Kostenaufteilungsgesetzes (Ausstoß in kg CO2 je m² Wohnfläche und Jahr). Für neu eingebaute Heizungen sieht das Gebäudemodernisierungsgesetz ab 2028 abweichende Regeln vor. Vor jeder Abrechnung den aktuellen Stand prüfen.

### K19 Nebenkostenabrechnung – Rechenweg
Gemeint ist die Betriebskostenabrechnung des vermietenden Eigentümers an seinen Mieter. Die Abrechnung der GdWE gegenüber den Eigentümern ist K10.

1. **Eingaben abfragen:** Abrechnungszeitraum (höchstens 12 Monate), Mietzeit darin, laut Mietvertrag umlegbare Kostenarten und vereinbarte Schlüssel, Hausgeld-Einzelabrechnung der Einheit, direkt gezahlte Kosten (z. B. Grundsteuer), Heizkostenabrechnung, geleistete Vorauszahlungen.
2. **Umlagefähig filtern:** Nur Kostenarten nach § 2 BetrKV, die der Mietvertrag nennt. Nicht umlagefähig sind insbesondere Verwaltervergütung, Erhaltungsrücklage, Reparaturen und Bankgebühren der GdWE; Kabel-TV-Gebühren seit 1.7.2024 nicht mehr.
3. **Schlüssel bestimmen:** Vereinbarung im Mietvertrag. Fehlt sie, gilt bei vermieteter Eigentumswohnung der Schlüssel der GdWE (§ 556a Abs. 3 BGB), sonst die Wohnfläche (§ 556a Abs. 1 BGB). Heiz- und Warmwasserkosten nach Heizkostenverordnung.
4. **Rechnen je Kostenart:** Anteil = Gesamtkosten × Anteil der Einheit am Schlüssel × Miettage ÷ Tage des Abrechnungszeitraums. Bei erfasstem Verbrauch nach Zählerständen statt nach Zeitanteil.
5. **Abzüge:** Den Vermieteranteil an den CO2-Kosten, Leerstand und nicht vereinbarte Kostenarten trägt der Vermieter.
6. **Ergebnis:** Summe der Anteile minus tatsächlich geleistete Vorauszahlungen = Nachzahlung oder Guthaben. Dazu ein Vorschlag für die neue Vorauszahlung (ein Zwölftel des Jahresbetrags).
7. **Rechenprobe:** Jede Zeile nachrechnen, Summe der Zeilen = Gesamtanteil; Kosten je m² und Monat ausweisen und auffällige Werte markieren.
8. **Ausgabe:** Tabelle mit Kostenart, Gesamtkosten, Schlüssel, Anteil der Einheit, Betrag; darunter Vorauszahlungen und Saldo; Erläuterung der Schlüssel; Ausweis nach § 35a EStG; Hinweis auf Belegeinsicht; Anschreiben. Der Zugang beim Mieter muss vor Fristablauf nachweisbar sein, sonst entfällt die Nachforderung.

### K20 Geldbestand-Nachweis
Je Konto: Bezeichnung, Stand laut Auszug zum Stichtag, Stand laut Buchhaltung, Differenz mit Erklärung (z. B. schwebende Posten). Die Summe muss dem Endbestand in K10 und dem Rücklagenstand in K12 entsprechen. Beleg ist der Kontoauszug oder die Saldenbestätigung der Bank; fehlt er, den Nachweis als offenen Punkt führen.

## Ausgabeformat

- Kopfzeile: Postencode, Objekt, Zeitraum, Datenstand.
- Zahlen in Tabellen, Beträge in Euro mit zwei Nachkommastellen.
- Am Ende immer: „Offene Punkte“ (fehlende Belege, Annahmen) und „Nächster Schritt“ mit Zuständigem und Frist.
- Schreiben an Eigentümer oder Firmen als versandfertigen Entwurf.

## „Zeige alle Posten“

Bei dieser Bitte den Postenkatalog K1–K20 als Tabelle ausgeben und um die Spalten **Zuständig**, **Nächste Frist**, **Status** (offen / läuft / erledigt / entfällt) ergänzen. Bekannte Stände eintragen, unbekannte als „offen – Angabe fehlt“ markieren. Für die Gesamtsicht über K, T und O auf `hausverwaltung-organisation-recht` verweisen.