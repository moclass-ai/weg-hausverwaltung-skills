---
name: "hausverwaltung-technisch"
description: "Technische Hausverwaltung: Begehung, Wartungsplan, Prüfpflichten, Sicherheitscheck, Schadensmeldung, Notfall, Erhaltungsplanung, Gewährleistung, Versicherungsschäden. Auch bei \"zeige alle Posten Technik\"."
---

# Hausverwaltung – Technische Verwaltung (Posten T1–T20)

Dieser Skill deckt alles ab, was Gebäude, Anlagen und Grundstück in Schuss hält. Schwerpunkt: Gemeinschaftseigentum einer WEG in Deutschland, auch in Selbstverwaltung. Geschwister-Skills: `hausverwaltung-kaufmaennisch` (K-Posten) und `hausverwaltung-organisation-recht` (O-Posten, dort auch die Gesamtübersicht).

**Rechtsstand: November 2026.** Das Gebäudeenergiegesetz heißt seit 29.7.2026 Gebäudemodernisierungsgesetz (GModG). Prüf- und Wartungspflichten ergeben sich zusätzlich aus Landesrecht und Verordnungen. Auftraggeberin und Anspruchsinhaberin ist die Gemeinschaft der Wohnungseigentümer (GdWE).

## Grundregeln

1. **Gemeinschafts- oder Sondereigentum zuerst klären.** Die Zuordnung steht in Teilungserklärung und Gemeinschaftsordnung. Nicht raten: nachsehen lassen oder als offene Frage markieren. Davon hängt ab, wer beauftragt und wer zahlt.
2. **Sicherheit vor Verfahren.** Bei Gefahr für Personen oder drohendem Folgeschaden zuerst die Notmaßnahme nennen (T6), danach Beschluss und Kosten klären.
3. **Nur prüfen, was vorhanden ist.** Wartungs- und Prüfpflichten hängen von den Anlagen im Haus und teils vom Bundesland ab. Frage das Anlagenverzeichnis ab (T1), bevor du Pflichten aufzählst. Intervalle und Pflichten, auf die es ankommt, per Websuche auf aktuellen Stand prüfen.
4. **Aufträge brauchen eine Grundlage.** Laufende Kleinigkeiten im beschlossenen Rahmen, alles Größere per Beschluss (Übergabe an O6). Ein bestellter Verwalter darf ohne Beschluss nur Maßnahmen von untergeordneter Bedeutung ohne erhebliche Verpflichtungen treffen und solche, die eine Frist wahren oder einen Nachteil abwenden (§ 27 Abs. 1 WEG). Ohne Verwalter braucht es einen Beschluss oder eine beschlossene Ermächtigung. Du benennst, welcher Fall vorliegt.
5. **Dokumentieren.** Jede Begehung, Meldung, Beauftragung und Abnahme mit Datum, Foto-Hinweis und Zuständigem festhalten. Das ist im Schadensfall der Nachweis der Verkehrssicherung.
6. Keine Rechts- oder Statikberatung. Bei Tragwerk, Brandschutz, Schadstoffen, Gas und Elektro immer Fachfirma oder Sachverständigen einplanen.

## Postenkatalog

| Code | Posten | Was zu tun ist | Turnus |
|---|---|---|---|
| T1 | Objektakte & Anlagenverzeichnis | Bauteile und Anlagen mit Baujahr, Hersteller, Wartungsfirma, Plänen, Gewährleistungsende erfassen | einmalig, laufend pflegen |
| T2 | Regelbegehung | Rundgang Dach bis Keller und Außenanlagen nach Checkliste, Protokoll mit Mängelliste und Priorität | 1–2× jährlich, nach Sturm |
| T3 | Wartungsplan & Prüfpflichten | Kalender für Heizung, Schornsteinfeger, Trinkwasser/Legionellen, Rauchwarnmelder, Aufzug, Feuerlöscher/Brandschutz, Elektroprüfung, Tore, Hebeanlage/Rückstau, Blitzschutz, Spielplatz – je nach Bestand | laufend |
| T4 | Verkehrssicherung | Winterdienst, Wege, Treppen, Beleuchtung, Geländer, Baumkontrolle, Dach/Dachrinnen; Nachweise führen | saisonal, laufend |
| T5 | Schadensmeldung & Störung | Meldung aufnehmen, Zuständigkeit klären, Priorität vergeben, Firma beauftragen, Rückmeldung an Melder | laufend |
| T6 | Notfälle | Wasser, Heizungsausfall, Sturm, Strom, Einbruch: Sofortmaßnahme, Notdienstliste, Schadensminderung, Meldung an Versicherung | bei Ereignis |
| T7 | Kleinreparaturen & laufende Erhaltung | Kleine Aufträge im beschlossenen Budget vergeben, Ausführung kontrollieren | laufend |
| T8 | Erhaltungsplanung | 5–10-Jahres-Plan je Bauteil mit Zustand, Restlebensdauer, Kostenschätzung; Abgleich mit Rücklage (K8) | jährlich fortschreiben |
| T9 | Größere Maßnahmen | Leistungsbeschreibung, Vergleichsangebote, Preisspiegel, Beschlussvorlage, Vergabe, Bauüberwachung, Abnahme, Schlussrechnung | je Projekt |
| T10 | Gewährleistung & Mängel | Fristenliste, Mängelanzeige mit Fristsetzung, Gutachter, Sicherung der Ansprüche vor Verjährung (mit O18) | laufend, vor Fristablauf |
| T11 | Hausmeister & Dienstleister | Leistungsverzeichnis für Hausmeister, Reinigung, Garten, Winterdienst; Kontrolle und Reklamation | laufend |
| T12 | Energie & Messwesen | Zähler und Ablesung, fernablesbare Messtechnik (Nachrüstfrist 31.12.2026, § 5 Abs. 3 HeizkostenV), Energieausweis, Heizungseinstellung und -optimierung, Verbrauchsauffälligkeiten | jährlich, laufend |
| T13 | Versicherungsschäden | Schaden dokumentieren, melden, Angebote, Regulierung nachhalten, Abgrenzung Gebäude-/Hausrat-/Haftpflicht | bei Ereignis |
| T14 | Bauliche Veränderungen einzelner Eigentümer | Antrag technisch prüfen (Wallbox, Steckersolar, Markise, Klimagerät, Barrierefreiheit), privilegierte Maßnahme nach § 20 Abs. 2 WEG ja/nein, Auflagen formulieren, an O6 übergeben | bei Antrag |
| T15 | Schließanlage & Schlüssel | Schließplan, Sicherungskarte, Schlüsselausgabe-Liste, Nachbestellung, Verlustfall | laufend |
| T16 | Müll, Außenanlagen, Gemeinschaftsflächen | Tonnen und Abfuhr, Grünpflege, Stellplätze, Fahrradraum, Keller, Waschküche | laufend |
| T17 | Modernisierung & Förderung | Energetische Maßnahmen, Heizungstausch nach Gebäudemodernisierungsgesetz und kommunaler Wärmeplanung, PV, Fördermittel und Fristen prüfen, Variantenvergleich | bei Bedarf |
| T18 | Mieteinheiten technisch (nur vermietete Einheiten) | Wohnungsübergabe mit Protokoll, Mängelmeldungen der Mieter, Zählerstände, Instandsetzung im Sondereigentum | bei Bedarf |
| T19 | Sicherheitseinrichtungen-Check | Rauchwarnmelder, Feuerlöscher, Rauch- und Wärmeabzug, Brandschutztüren und Türschließer, Flucht- und Rettungswege, Sicherheitsbeleuchtung, Blitzschutz, Aufzugsnotruf, Absturzsicherungen; Checkliste mit Nachweisen | jährlich, nach Ereignis |
| T20 | Versicherungsschäden im Sondereigentum | Zuordnung Gemeinschafts- oder Sondereigentum, Deckung über die Gebäudeversicherung der GdWE oder die private Versicherung des Eigentümers, Meldung, Koordination, Weiterleitung der Entschädigung, Selbstbehalt; Mehrleistung und Vergütung klären | bei Ereignis |

## Arbeitsweisen für die Kernposten

### T2 Begehungsprotokoll
Reihenfolge: Dach und Entwässerung, Fassade und Fenster außen, Balkone, Treppenhaus, Türen/Schließanlage, Keller und Technikräume, Heizung, Elektro-Hauptverteilung (nur Sichtprüfung), Tiefgarage/Stellplätze, Außenanlagen und Wege, Müllplatz. Je Befund: Ort, Beschreibung, Foto-Hinweis, Priorität (A sofort / B binnen 3 Monaten / C einplanen), Zuständig, geschätzte Größenordnung.

### T5 Schadensmeldung – Triage
1. Was, wo, seit wann, wer meldet, Fotos?
2. Gefahr oder Folgeschaden? Dann T6.
3. Gemeinschafts- oder Sondereigentum?
4. Versicherungsfall möglich? Dann T13 parallel.
5. Priorität, Firma, Termin, Rückmeldung an den Melder. Ausgabe als Ticket mit laufender Nummer.

### T6 Notfall
Sofortmaßnahmen zuerst und knapp (z. B. Hauptabsperrung schließen, Strom im betroffenen Bereich aus, Bereich sichern), dann Notdienst, dann Dokumentation mit Fotos vor der Beseitigung, dann Versicherung. Jeder Eigentümer darf Maßnahmen treffen, die einen unmittelbar drohenden Schaden abwenden (§ 18 Abs. 3 WEG); ein bestellter Verwalter handelt nach § 27 Abs. 1 Nr. 2 WEG. Fehlt eine Notdienstliste, eine anlegen: Heizung, Sanitär, Elektro, Schlüsseldienst, Dachdecker, Versorger, Versicherung.

### T9 Angebotsvergleich
Preisspiegel als Tabelle: Positionen gleichnamig machen, Mengen angleichen, fehlende Positionen markieren, Netto/Brutto, Ausführungszeit, Gewährleistung, Zahlungsbedingungen, Referenzen. Empfehlung mit Begründung, nicht automatisch das billigste Angebot. Dazu die Angaben, die O6 für den Beschluss braucht: Maßnahme, Firma, Kostenobergrenze, Finanzierung, Kostenverteilung.

### T3 Wartungskalender
Tabelle je Anlage: Pflicht oder Empfehlung, Intervall, letzte Durchführung, nächste Fälligkeit, Firma, Vertrag vorhanden, Nachweis abgelegt. Überfällige Punkte oben.

### T12 Fernablesbare Messtechnik
Bestand aufnehmen: je Gerätetyp (Heizkostenverteiler, Wärmemengenzähler, Warmwasserzähler) fernablesbar ja/nein, Einbaujahr, Eichfrist, Vertragslaufzeit des Messdienstes. Nicht fernablesbare Geräte bis 31.12.2026 nachrüsten oder tauschen. Seit 1.12.2022 eingebaute Geräte müssen zusätzlich interoperabel und an ein Smart-Meter-Gateway anbindbar sein; ältere fernablesbare Geräte sind dafür bis 31.12.2031 nachzurüsten. Eine Ausnahme wegen technischer Unmöglichkeit oder unangemessenem Aufwand begründen und dokumentieren. Beschlussbedarf an O6, Kostenfolgen an K11.

### T14 Bauliche Veränderungen einzelner Eigentümer
Jeder Eigentümer kann angemessene bauliche Veränderungen verlangen, die der Barrierefreiheit, dem Laden von Elektrofahrzeugen, dem Einbruchsschutz, dem Anschluss an ein Telekommunikationsnetz mit sehr hoher Kapazität (Glasfaser) oder der Stromerzeugung durch Steckersolargeräte dienen (§ 20 Abs. 2 WEG). Über das Ob besteht dann ein Anspruch, über die Durchführung beschließt die Gemeinschaft. Grenze: keine grundlegende Umgestaltung der Anlage und keine unbillige Benachteiligung einzelner (§ 20 Abs. 4 WEG). Die Kosten trägt grundsätzlich, wer die Maßnahme verlangt (§ 21 Abs. 1 WEG). Ausgabe: technische Stellungnahme, Auflagen (Fachfirma, Leitungsweg, Rückbau, Haftung, Versicherung), Übergabe an O6.

### T17 Heizung und Modernisierung
Seit 29.7.2026 gilt das Gebäudemodernisierungsgesetz; die frühere Vorgabe von 65 % erneuerbaren Energien bei neuen Heizungen ist entfallen. Übergangsregeln, Quoten und Förderbedingungen ändern sich weiter. Vor jeder Empfehlung den aktuellen Gesetzes- und Förderstand per Websuche prüfen, die kommunale Wärmeplanung abfragen und Varianten mit Investition, Förderung, Betriebskosten und CO2-Kosten vergleichen. Keine Aussage „Pflicht“ oder „verboten“ ohne geprüfte Fundstelle.

### T19 Sicherheitseinrichtungen-Check
Checkliste je Einrichtung: vorhanden ja/nein, Pflicht oder Empfehlung (Landesbauordnung, Baugenehmigung, Brandschutzkonzept), Prüfintervall, letzte Prüfung, Prüfer, Nachweis, Mangel, Frist. Umfang: Rauchwarnmelder (Einbau und Wartung nach Landesrecht; klären, ob Gemeinschaft oder Eigentümer zuständig ist), Feuerlöscher, Rauch- und Wärmeabzug, Brandschutztüren und Feststellanlagen, freie Flucht- und Rettungswege ohne Brandlasten im Treppenhaus, Sicherheitsbeleuchtung, Blitzschutz, Aufzugsnotruf, Geländer und Absturzsicherungen, Garagentore, Feuerwehrzufahrt. Mängel mit Gefahr sofort nach T6 behandeln. Das Ergebnis fließt in den Wartungskalender (T3).

### T20 Versicherungsschäden im Sondereigentum
1. Schaden aufnehmen wie T5; Ursache und betroffene Bauteile nach Gemeinschafts- und Sondereigentum trennen.
2. Deckung klären: Die Wohngebäudeversicherung der GdWE umfasst regelmäßig das ganze Gebäude einschließlich Sondereigentum. Hausrat und Haftpflicht des Eigentümers oder Mieters laufen getrennt.
3. Meldung an den Versicherer durch die GdWE als Versicherungsnehmerin; der Eigentümer liefert Fotos, Kostenvoranschläge und Zugang.
4. Entschädigung für Sondereigentum an den betroffenen Eigentümer weiterleiten, Zahlungsfluss in K7 belegen.
5. Selbstbehalt: Verteilung laut Vereinbarung oder Beschluss; ohne Regelung wie die Prämie nach dem allgemeinen Schlüssel. Stand der Rechtsprechung prüfen.
6. Der Aufwand für die Abwicklung im Sondereigentum ist eine Mehrleistung; Vergütung nur bei vertraglicher oder beschlossener Grundlage.

## Ausgabeformat

- Kopfzeile: Postencode, Objekt, Datum.
- Befunde und Pläne als Tabelle, Schreiben an Firmen als versandfertige Entwürfe (Angebotsanfrage, Auftrag, Mängelanzeige mit Frist, Schadensmeldung an Versicherung).
- Am Ende: „Offene Punkte“ und „Nächster Schritt“ mit Zuständigem und Frist. Kosten als Größenordnung nur mit Hinweis, dass ein Angebot nötig ist.

## „Zeige alle Posten“

Bei dieser Bitte den Postenkatalog T1–T20 als Tabelle ausgeben und um die Spalten **Zuständig**, **Nächste Frist**, **Status** (offen / läuft / erledigt / entfällt) ergänzen. Posten zu Anlagen, die es im Haus nicht gibt, als „entfällt“ führen statt weglassen. Für die Gesamtsicht über K, T und O auf `hausverwaltung-organisation-recht` verweisen.