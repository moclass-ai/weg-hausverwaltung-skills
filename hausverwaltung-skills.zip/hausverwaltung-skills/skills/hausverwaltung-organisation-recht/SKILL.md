---
name: "hausverwaltung-organisation-recht"
description: "Organisation und Recht der Hausverwaltung: Eigentümerversammlung, Beschlüsse, Protokoll, Hausordnung, Verträge, Schriftverkehr, Beirat, Verwalterwechsel. Auch bei \"zeige alle Posten\" (Gesamtübersicht)."
---

# Hausverwaltung – Organisation & Recht (Posten O1–O25)

Dieser Skill ist die Schaltzentrale: Versammlung, Beschlüsse, Verträge, Kommunikation, Fristen und die Gesamtübersicht aller Posten. Schwerpunkt: WEG in Deutschland, auch in Selbstverwaltung. Geschwister-Skills: `hausverwaltung-kaufmaennisch` (K1–K20) und `hausverwaltung-technisch` (T1–T20).

**Rechtsstand: November 2026** (WEG in der Fassung der Änderung vom 10.10.2024, in Kraft seit 17.10.2024). Rechtsträgerin ist die **Gemeinschaft der Wohnungseigentümer (GdWE)**: Sie verwaltet, schließt Verträge, klagt und wird verklagt (§§ 9a, 18 Abs. 1 WEG).

## Grundregeln

1. **Regelwerk vor Gesetz vor Gewohnheit.** Erst Teilungserklärung/Gemeinschaftsordnung und bestehende Beschlüsse prüfen, dann das WEG. Liegt das Regelwerk nicht vor, die Lücke benennen.
2. **Paragraphen sind Orientierung, keine Rechtsberatung.** Wenn Frist, Mehrheit oder Form die Antwort trägt, den aktuellen Rechtsstand per Websuche prüfen. Bei Anfechtung, Klage, Haftung, Gewährleistungsstreit auf Fachanwalt für Miet- und WEG-Recht oder Eigentümerverband verweisen.
3. **Vertretung klären, bevor etwas unterschrieben wird.** Ohne bestellten Verwalter vertreten alle Eigentümer die Gemeinschaft gemeinschaftlich (§ 9b Abs. 1 WEG). Bei jedem Vertrag, Bankgeschäft und Schreiben mit Rechtswirkung angeben, wer unterschreiben muss oder welche Vollmacht nötig ist.
4. **Beschlüsse müssen bestimmt sein.** Wer macht was, bis wann, zu welchen Höchstkosten, aus welchem Topf, nach welchem Schlüssel.
5. **Neutral bleiben.** Schreiben an Eigentümer sachlich und gleich behandelnd, auch im Konflikt. Keine Wertung über einzelne Personen.
6. **Datenschutz.** Eigentümerdaten nur für Verwaltungszwecke, in Rundschreiben keine Zahlungsrückstände einzelner nennen, sofern nicht für die Beschlussfassung nötig.
7. **Nur geprüfte Fundstellen.** Trägt ein Paragraph oder Urteil die Antwort, die Fundstelle nennen und nur zitieren, was geprüft wurde. Keine Aktenzeichen aus dem Gedächtnis.

## Postenkatalog

| Code | Posten | Was zu tun ist | Turnus |
|---|---|---|---|
| O1 | Regelwerk | Teilungserklärung, Gemeinschaftsordnung, Aufteilungsplan, Hausordnung, geltende Beschlüsse auswerten; Kurzfassung der wichtigsten Regeln (Stimmrecht, Schlüssel, Zustimmungen) | einmalig, bei Änderung |
| O2 | Verwaltungsmodell & Vertretung | Selbstverwaltung mit gemeinschaftlicher Vertretung oder Eigentümer als bestellter Verwalter; Vollmachten, Geschäftsverteilungsplan, Beirat (§ 29 WEG), Vertretungsregel für Bank und Verträge; Anspruch auf zertifizierten Verwalter prüfen (§ 19 Abs. 2 Nr. 6, § 26a WEG) | einmalig, jährlich prüfen |
| O3 | Verwalterwechsel & Übernahme | Herausgabe aller Unterlagen, Rechnungslegung des Vorverwalters, Kontenübertragung, Vertragsübersicht, Zugangsdaten, Schlüssel, offene Vorgänge und Rechtsstreite, Übergabeprotokoll | bei Wechsel |
| O4 | Jahreskalender & Fristen | Alle wiederkehrenden Termine aus K, T und O in einem Kalender; Vorwarnzeiten | laufend |
| O5 | Versammlung vorbereiten | Termin, Ort oder Online-Format, Tagesordnung, Einladung in Textform, Frist soll mindestens drei Wochen betragen (§ 24 Abs. 4 WEG), Anlagen, Vollmachtsformular | mindestens jährlich (§ 24 Abs. 1 WEG) |
| O6 | Beschlussvorlagen | Beschlusstext, Begründung, Kosten und Finanzierung, Kostenverteilung, erforderliche Mehrheit, Alternativen | je Tagesordnungspunkt |
| O7 | Versammlung durchführen | Leitfaden für den Vorsitz, Anwesenheits- und Vollmachtsliste, Stimmkraft, Abstimmung, Ergebnis verkünden | je Versammlung |
| O8 | Niederschrift | Protokoll mit Beschlüssen im Wortlaut und Abstimmungsergebnis, Unterschriften, Versand | unverzüglich danach |
| O9 | Beschluss-Sammlung | Jeden Beschluss und jede Gerichtsentscheidung fortlaufend nummeriert eintragen (§ 24 Abs. 7 WEG); ohne Verwalter führt sie der Versammlungsvorsitz, sofern kein anderer bestimmt ist (§ 24 Abs. 8 WEG) | unverzüglich |
| O10 | Umlaufbeschlüsse | Beschluss in Textform außerhalb der Versammlung, Zustimmung aller in Textform nötig, außer die Eigentümer haben für diesen einzelnen Gegenstand die Mehrheit der abgegebenen Stimmen zugelassen (§ 23 Abs. 3 WEG); Fristsetzung, Ergebnis mitteilen | bei Bedarf |
| O11 | Beschlussverfolgung | Liste aller Beschlüsse mit Zuständigem, Frist, Stand; Bericht an Eigentümer | laufend |
| O12 | Vertragsregister | Alle Verträge der Gemeinschaft mit Partner, Leistung, Kosten, Laufzeit, Kündigungsfrist; Ausschreibung und Kündigung vorbereiten | jährlich prüfen |
| O13 | Versicherungen | Wohngebäude, Haus- und Grundbesitzerhaftpflicht, weitere je nach Objekt, Absicherung für Beirat/ehrenamtlich Handelnde; Deckung und Summe prüfen (Gebäudeversicherung zum Neuwert und Haftpflicht gehören zur ordnungsmäßigen Verwaltung, § 19 Abs. 2 Nr. 3 WEG) | jährlich |
| O14 | Eigentümerkommunikation | Rundschreiben, Aushänge, Antworten auf Anfragen, Einsicht in Verwaltungsunterlagen (§ 18 Abs. 4 WEG) | laufend |
| O15 | Hausordnung & Konflikte | Hinweis, Abmahnung, Vermittlungsvorschlag bei Lärm, Nutzung, Tierhaltung, Müll; Eskalationsstufen | bei Bedarf |
| O16 | Eigentümerwechsel | Daten des Erwerbers, Zustimmung zur Veräußerung falls vereinbart (§ 12 WEG), Unterlagenpaket für Verkäufer/Käufer, Übergabe an K18 | bei Verkauf |
| O17 | Eigentümerliste & Datenschutz | Aktuelle Liste mit Anschrift und Kontaktweg, Einwilligungen für E-Mail-Versand, Auskunftsanfragen | laufend |
| O18 | Rechtliche Vorgänge | Hausgeldklage, Beschlussanfechtung (Klage gegen die GdWE binnen eines Monats, Begründung binnen zwei Monaten ab Beschlussfassung, §§ 44, 45 WEG), Gewährleistungs- und Schadensersatzansprüche, Anwalt mandatieren, Behördenpost | bei Bedarf |
| O19 | Ablage & Aufbewahrung | Aktenplan digital und Papier; Regelwerk, Protokolle, Beschluss-Sammlung und Pläne dauerhaft; Aufbewahrungsfristen laut Arbeitsweise O19 | laufend |
| O20 | Dienstleister & Personal organisatorisch | Hausmeister- und Dienstleisterverträge, Anmeldung bei Beschäftigung, Vertretungsregel, Jahresgespräch | jährlich |
| O21 | Mietverwaltung organisatorisch (nur vermietete Einheiten) | Mietvertrag, Mieterwechsel, Kündigung, Mieterhöhungsschreiben, Mieterkommunikation, Weitergabe der Hausordnung | bei Bedarf |
| O22 | Gesamtübersicht aller Posten | Statusliste über K, T und O mit Zuständigem, Frist, Stand | monatlich |
| O23 | Hausordnung erstellen & ändern | Entwurf nach Bausteinen, Abgleich mit Gemeinschaftsordnung und bestehenden Beschlüssen, Beschlussvorlage (§ 19 Abs. 2 Nr. 1 WEG), Bekanntgabe an Eigentümer und Mieter | einmalig, bei Änderungsbedarf |
| O24 | Allgemeiner Schriftverkehr | Post von und an Behörden, Versorger, Firmen, Versicherer, Nachbarn; Posteingangsliste, Fristen, Wiedervorlage, versandfertige Entwürfe | laufend |
| O25 | Beiratsinformation & Kopien wichtiger Vorgänge | Festlegen, was Beirat und Eigentümer unaufgefordert erhalten; Verteiler, Versandnachweis, Datenschutz | laufend, je Vorgang |

## Arbeitsweisen für die Kernposten

### O3 Verwalterwechsel – Übernahme-Checkliste
Anfordern und abhaken: Teilungserklärung mit Nachträgen, Beschluss-Sammlung, alle Protokolle, Eigentümerliste, Abrechnungen und Wirtschaftspläne, Buchhaltung und Belege, Kontoauszüge und Saldenbestätigung zum Stichtag, Rücklagennachweis, alle Verträge und Versicherungspolicen, Wartungsnachweise, Pläne und Bauakten, Gewährleistungsunterlagen und Gutachten, Schlüssel und Schließplan, Zugangsdaten zu Portalen, Liste offener Vorgänge und Rechtsstreite. Dazu: Schreiben an den Vorverwalter mit Frist, Übergabeprotokoll, Umschreibung von Konten und Verträgen, Information an Versorger, Versicherer und Dienstleister.

### O5 Einladung
Pflichtinhalte: Einladende Person und deren Berechtigung, Datum, Uhrzeit, Ort, Tagesordnung mit so genauer Bezeichnung jedes Punkts, dass erkennbar ist, worüber beschlossen wird, Anlagen (Abrechnung, Plan, Angebote), Hinweis auf Vollmacht in Textform. Ohne Verwalter klären, wer einberufen darf (Beiratsvorsitz, dessen Vertretung oder ein per Beschluss ermächtigter Eigentümer). Rückwärtsplan ab Versammlungstag ausgeben.

Formate: Die Online-Teilnahme an einer Präsenzversammlung setzt einen Beschluss voraus (§ 23 Abs. 1 Satz 2 WEG). Rein virtuelle Versammlungen können mit mindestens drei Vierteln der abgegebenen Stimmen für längstens drei Jahre beschlossen werden und müssen einer Präsenzversammlung vergleichbar sein (§ 23 Abs. 1a WEG). Wird dieser Beschluss vor dem 1.1.2028 gefasst, bleibt bis einschließlich 2028 mindestens eine Präsenzversammlung pro Jahr nötig, sofern nicht einstimmig darauf verzichtet wird (§ 48 Abs. 6 WEG). Das Gesetz kennt seit 2020 kein Quorum für die Beschlussfähigkeit mehr; abweichende Regeln der Gemeinschaftsordnung prüfen. Mehr als ein Viertel der Eigentümer kann die Einberufung in Textform verlangen (§ 24 Abs. 2 WEG).

### O6 Beschlussvorlage
Aufbau je Punkt: Überschrift, Sachverhalt in drei Sätzen, **Beschlusstext im Wortlaut**, Kosten mit Obergrenze, Finanzierung (laufende Mittel, Rücklage, Sonderumlage), Kostenverteilung mit Schlüssel, Ausführung (wer, bis wann), erforderliche Mehrheit mit Fundstelle, Hinweis auf Anfechtungsrisiken. Bei baulichen Veränderungen (§ 20 WEG) Kostentragung nach § 21 WEG gesondert darstellen.

### O8 Niederschrift
Kopf mit Ort, Datum, Beginn/Ende, Vorsitz, Protokollführung, anwesenden und vertretenen Stimmen. Je Punkt: Beschlusstext im Wortlaut, Ja/Nein/Enthaltung, verkündetes Ergebnis. Keine Wortbeiträge nacherzählen. Unterschriftenzeilen laut § 24 Abs. 6 WEG. Danach sofort O9 und O11 füllen.

### O4 Jahreskalender
Standardrhythmus als Vorschlag, an das Objekt anpassen:
- Januar–Februar: Buchhaltung abschließen, Ablesewerte, Belegprüfung terminieren
- März–Mai: Jahresabrechnung, Vermögensbericht, Wirtschaftsplan, Frühjahrsbegehung
- Mai–Juni: Eigentümerversammlung, Protokoll, Beschluss-Sammlung
- Juli–September: Beschlüsse umsetzen, Maßnahmen ausführen, Vertragsregister und Versicherungen prüfen
- Oktober–November: Heizung und Winterdienst vorbereiten, Herbstbegehung, Kündigungsfristen
- Dezember: Zählerstände, Jahresabschluss vorbereiten, Kalender für das Folgejahr

### O2 Verwaltungsmodell prüfen
- Ohne bestellten Verwalter vertreten alle Eigentümer gemeinschaftlich (§ 9b Abs. 1 WEG). Für das Tagesgeschäft Vollmachten oder Ermächtigungsbeschlüsse vorbereiten (Bank, Versicherer, Handwerker, Einberufung).
- Mit bestelltem Verwalter: Bestellung höchstens fünf Jahre, bei der ersten Bestellung nach Begründung des Wohnungseigentums höchstens drei (§ 26 Abs. 2 WEG). Abberufung jederzeit; der Vertrag endet spätestens sechs Monate danach (§ 26 Abs. 3 WEG). Gegenüber dem Verwalter vertritt der Beiratsvorsitz oder ein per Beschluss ermächtigter Eigentümer die GdWE (§ 9b Abs. 2 WEG).
- Zertifizierter Verwalter: Jeder Eigentümer kann die Bestellung eines zertifizierten Verwalters verlangen. Die Ausnahme greift nur, wenn weniger als neun Sondereigentumsrechte bestehen, ein Eigentümer zum Verwalter bestellt ist und weniger als ein Drittel der Eigentümer einen zertifizierten Verwalter verlangt (§ 19 Abs. 2 Nr. 6 WEG). Die Zahl der Sondereigentumsrechte laut Teilungserklärung zählen, nicht schätzen.
- Ausgabe: Entscheidungsvorlage mit Aufgabenverteilung, Vertretungsregel, Haftung und Versicherung der Handelnden, Kosten.

### O19 Aufbewahrung
Das WEG regelt keine Aufbewahrungsfristen; üblich ist die Orientierung an Handels- und Steuerrecht: Buchungsbelege und Rechnungen acht Jahre, Abrechnungen und Bücher zehn Jahre, Korrespondenz sechs Jahre. Dauerhaft bleiben Teilungserklärung, Gemeinschaftsordnung, Pläne, Niederschriften, Beschluss-Sammlung und Bauakten; Gewährleistungs- und Versicherungsunterlagen mindestens bis Fristende. Vernichtung nur nach Beschluss mit Liste. Fristen vor der Vernichtung aktuell prüfen.

### O23 Hausordnung
Bausteine: Ruhezeiten, Lüften und Heizen, Treppenhaus und Fluchtwege, Müll, Reinigung, Tierhaltung, Grillen, Fahrräder und Kinderwagen, Stellplätze, Gemeinschaftsräume, Balkon und Fassade, Türen und Schlüssel, Meldewege.

1. Enthält die Gemeinschaftsordnung schon eine Hausordnung oder Regeln dazu? Diese gehen vor; ein Mehrheitsbeschluss kann Vereinbartes nicht ändern.
2. Jede Regel muss bestimmt, sachlich begründet und für alle gleich sein. Generelle Verbote (etwa Tierhaltung oder Musizieren insgesamt) und Pflichten zur persönlichen Arbeitsleistung sind per Mehrheitsbeschluss regelmäßig nicht haltbar; stattdessen zeitliche und sachliche Grenzen wählen.
3. Beschlussvorlage über O6, Beschluss in O9 eintragen.
4. Bekanntgabe: Versand an alle Eigentümer und Aushang; vermietende Eigentümer geben die Hausordnung an ihre Mieter weiter.
5. Durchsetzung über O15.

Ausgabe: Entwurf mit nummerierten Regeln, Gegenüberstellung zur alten Fassung, Beschlusstext.

### O24 Allgemeiner Schriftverkehr
Posteingangsliste führen: Eingang, Absender, Betreff, Frist, zuständig, erledigt. Behördenpost (Bescheide, Anhörungen, Auflagen) sofort auf Frist und Rechtsbehelf prüfen und an O18 geben, wenn Rechtsfolgen drohen. Jedes ausgehende Schreiben nennt die GdWE als Absenderin mit Anschrift der Anlage, Bezug oder Aktenzeichen, Sachverhalt, konkrete Bitte oder Erklärung und Frist; Unterschrift gemäß Vertretungsregel (Grundregel 3). Standardfälle: Auskunft und Antrag bei Behörden, Zählerstände und Vertragsänderung bei Versorgern, Angebotsanfrage, Auftrag und Mängelanzeige an Firmen (mit T9, T10), Meldung an Versicherer (T13, T20), Schreiben an Nachbarn.

### O25 Beiratsinformation
Verteilerplan beschließen lassen. Unaufgefordert an den Beirat: Entwürfe von Wirtschaftsplan und Jahresabrechnung zur Prüfung und Stellungnahme (§ 29 Abs. 2 WEG), Kontostände (K20), Angebote und Aufträge ab der beschlossenen Wertgrenze, Schadens- und Versicherungsfälle, Behörden- und Gerichtspost, Mahnstand als Summe. An alle Eigentümer: Niederschrift, Vermögensbericht, Beschlussverfolgung, wichtige Rundschreiben. Je Vorgang Datum, Empfänger und Versandweg festhalten. Datenschutz nach Grundregel 6; Einsicht in die Verwaltungsunterlagen steht jedem Eigentümer zu (§ 18 Abs. 4 WEG).

## Ausgabeformat

- Kopfzeile: Postencode, Objekt, Datum.
- Schreiben, Einladungen, Beschlusstexte und Protokolle versandfertig, mit Platzhaltern in eckigen Klammern für fehlende Angaben.
- Am Ende: „Offene Punkte“, „Wer muss unterschreiben“, „Nächster Schritt“ mit Frist.

## „Zeige alle Posten“ – Gesamtübersicht

Bei dieser Bitte eine Tabelle über **alle** Posten ausgeben, mit den Spalten Code, Posten, Zuständig, Nächste Frist, Status (offen / läuft / erledigt / entfällt). Bekannte Stände eintragen, Unbekanntes als „offen – Angabe fehlt“. Die Liste ist vollständig zu führen:

**Kaufmännisch:** K1 Stammdaten & Verteilerschlüssel, K2 Bankkonten, K3 Wirtschaftsplan, K4 Hausgeld-Sollstellung & Einzug, K5 Zahlungsüberwachung & Mahnwesen, K6 Rechnungsprüfung & Zahlungsverkehr, K7 Laufende Buchhaltung, K8 Erhaltungsrücklage, K9 Sonderumlagen, K10 Jahresabrechnung, K11 Heiz- und Warmwasserkosten, K12 Vermögensbericht, K13 Belegprüfung, K14 Bescheinigung § 35a EStG, K15 Steuern, Abgaben, Personal, K16 Kosten-Controlling Verträge, K17 Soll-Ist & Liquidität, K18 Eigentümerwechsel kaufmännisch, K19 Mietverwaltung Finanzen & Nebenkostenabrechnung, K20 Geldbestand-Nachweis.

**Technisch:** T1 Objektakte & Anlagenverzeichnis, T2 Regelbegehung, T3 Wartungsplan & Prüfpflichten, T4 Verkehrssicherung, T5 Schadensmeldung & Störung, T6 Notfälle, T7 Kleinreparaturen, T8 Erhaltungsplanung, T9 Größere Maßnahmen, T10 Gewährleistung & Mängel, T11 Hausmeister & Dienstleister, T12 Energie & Messwesen, T13 Versicherungsschäden, T14 Bauliche Veränderungen einzelner Eigentümer, T15 Schließanlage & Schlüssel, T16 Müll, Außenanlagen, Gemeinschaftsflächen, T17 Modernisierung & Förderung, T18 Mieteinheiten technisch, T19 Sicherheitseinrichtungen-Check, T20 Versicherungsschäden im Sondereigentum.

**Organisation & Recht:** O1–O25 laut Katalog oben.

Danach die drei dringendsten Posten mit Begründung nennen und fragen, welcher zuerst bearbeitet werden soll.